class Bank{

 String Account_Name;
 int balanace;
 String Branch
 void UPI(){
Systemt.out.println("UPI Payment ");


void ATM{
System.out.println("ATM Transaction");

}
public class test{
public static void main(String [] args){



Bank SBI= new Bank();
SBI.Branch="Pune";
SBI.UPI();
System.out.println(SBI.Branch);


Bank Union=new Bank();
Union.balance=10000;
Union.ATM();
System.out.println(Union.balance);


Bank hdfc = new Bank();
hdfc.Account_Name="Om Ahire";'
System.out.println(hdfc.Account_Name);

hdfc.UPI();


}





}