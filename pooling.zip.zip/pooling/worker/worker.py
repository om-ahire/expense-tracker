import os
import redis
import json
import requests
import time
import logging

logging.basicConfig(level=logging.INFO)

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8080")

def process_vote_event(event_data):
    try:
        data = json.loads(event_data)
        poll_id = data.get("pollId")
        option_id = data.get("optionId")
        user_ip = data.get("userIp")

        if not all([poll_id, option_id, user_ip]):
            logging.error("Invalid vote payload: %s", data)
            return False

        # POST /vote/{pollId}/{optionId}
        url = f"{API_BASE_URL}/vote/{pollId}/{optionId}"
        
        # Retry mechanism (max 3 retries)
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = requests.post(url, json={"user_ip": user_ip})
                if response.status_code == 200:
                    logging.info(f"Successfully processed vote for poll {poll_id}, option {option_id} (IP: {user_ip})")
                    return True
                elif response.status_code == 400:
                    logging.warning(f"Vote rejected (likely duplicate): {response.text}")
                    return True # Don't retry user errors
                else:
                    logging.error(f"API Error {response.status_code} for poll {poll_id}: {response.text}")
            except Exception as req_e:
                logging.error(f"Request attempt {attempt+1} failed: {req_e}")
            
            time.sleep(1) # wait before retry
            
        logging.error("Failed to process event after 3 retries.")
        return False
    except Exception as e:
        logging.error(f"Error processing event: {e}")
        return False

def main():
    try:
        client = redis.from_url(REDIS_URL)
        client.ping()
        logging.info(f"Connected to Redis at {REDIS_URL}")
    except redis.ConnectionError:
        logging.error("Failed to connect to Redis")
        return

    logging.info("Worker listening on queue: vote_events...")
    while True:
        try:
            # blpop blocks until an item is available
            event = client.blpop("vote_events", timeout=0)
            if event:
                queue_name, data = event
                process_vote_event(data)
        except Exception as e:
            logging.error(f"Worker exception: {e}")
            time.sleep(2) # Backoff on redis errors

if __name__ == "__main__":
    main()
