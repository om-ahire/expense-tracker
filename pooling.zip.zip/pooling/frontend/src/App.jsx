import React, { useState, useEffect, useRef } from 'react';
import SockJS from 'sockjs-client';
import Stomp from 'stompjs';
import PollItem from './components/PollItem';
import './index.css';

const API_BASE = 'http://localhost:8080';

function App() {
  const [polls, setPolls] = useState([]);
  const [stompClient, setStompClient] = useState(null);
  
  // For creating a semantic poll
  const [newQuestion, setNewQuestion] = useState('');
  const [newOptions, setNewOptions] = useState(['', '']);

  useEffect(() => {
    fetchPolls();
    connectWebSocket();
    return () => {
      if (stompClient) stompClient.disconnect();
    };
  }, []);

  const fetchPolls = async () => {
    try {
      const res = await fetch(`${API_BASE}/poll`);
      const data = await res.json();
      // Initialize with empty votes logic
      setPolls(data);
    } catch (err) {
      console.error("Error fetching polls", err);
    }
  };

  const connectWebSocket = () => {
    const socket = new SockJS(`${API_BASE}/ws`);
    const client = Stomp.over(socket);
    client.debug = null; // disable debug logs

    client.connect({}, (frame) => {
      setStompClient(client);
      // We will subscribe to channels based on visible polls inside PollItem 
      // or globally here. For simplicity, we can pass stompClient to child components.
    }, (err) => {
      console.error("WebSocket Connection Error", err);
    });
  };

  const handleVote = async (pollId, optionId) => {
    try {
      // POST to /enqueue-vote
      await fetch(`${API_BASE}/enqueue-vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ pollId, optionId, userIp: 'frontend' })
      });
      // The WebSocket will automatically receive the updated counts and update the UI
    } catch (err) {
      console.error("Error voting", err);
    }
  };

  const handleCreatePoll = async (e) => {
    e.preventDefault();
    const validOptions = newOptions.filter(o => o.trim() !== '');
    if (!newQuestion || validOptions.length < 2) {
      alert("Please provide a question and at least 2 options.");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/poll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: newQuestion, options: validOptions })
      });
      if (res.ok) {
        setNewQuestion('');
        setNewOptions(['', '']);
        fetchPolls(); // Refresh list
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container">
      <header className="header">
        <h1>Live Polls</h1>
        <p>Real-time voting via WebSockets</p>
      </header>

      <div className="poll-grid" style={{ marginBottom: '3rem' }}>
        <div className="glass-panel" style={{ animationDelay: '0.1s' }}>
          <h2 className="poll-title">Create a New Poll</h2>
          <form className="create-poll-form" onSubmit={handleCreatePoll}>
            <input 
              placeholder="What's your question?" 
              value={newQuestion}
              onChange={(e) => setNewQuestion(e.target.value)}
            />
            {newOptions.map((opt, i) => (
              <input 
                key={i}
                placeholder={`Option ${i + 1}`} 
                value={opt}
                onChange={(e) => {
                  const newOpts = [...newOptions];
                  newOpts[i] = e.target.value;
                  setNewOptions(newOpts);
                }}
              />
            ))}
            <button className="btn-primary" type="button" onClick={() => setNewOptions([...newOptions, ''])}>+ Add Option</button>
            <button className="btn-primary" style={{ background: 'var(--success-color)' }} type="submit">Publish Poll</button>
          </form>
        </div>
      </div>

      <div className="poll-grid">
        {polls.map((poll, index) => (
          <PollItem 
            key={poll.id} 
            poll={poll} 
            stompClient={stompClient} 
            onVote={handleVote} 
            delay={`${0.2 + (index * 0.1)}s`}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
