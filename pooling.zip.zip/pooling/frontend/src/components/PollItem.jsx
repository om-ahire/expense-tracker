import React, { useEffect, useState, useRef } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip
);

const PollItem = ({ poll, stompClient, onVote, delay }) => {
  const [results, setResults] = useState([]);
  const subscriptionRef = useRef(null);

  useEffect(() => {
    // Initial dummy data for the chart based on options
    if (poll.options) {
      const initialResults = poll.options.map(opt => ({
        option_text: opt.text,
        vote_count: 0
      }));
      setResults(initialResults);
    }
  }, [poll]);

  useEffect(() => {
    if (stompClient && stompClient.connected) {
      // Subscribe to this specific poll
      subscriptionRef.current = stompClient.subscribe(`/topic/poll/${poll.id}`, (message) => {
        if (message.body) {
          const updatedResults = JSON.parse(message.body);
          setResults(updatedResults);
        }
      });
    }

    return () => {
      if (subscriptionRef.current) {
        subscriptionRef.current.unsubscribe();
      }
    };
  }, [stompClient, poll.id]);

  const chartData = {
    labels: results.map(r => r.option_text),
    datasets: [
      {
        label: 'Votes',
        data: results.map(r => r.vote_count),
        backgroundColor: [
          'rgba(59, 130, 246, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(139, 92, 246, 0.8)'
        ],
        borderRadius: 6,
        borderWidth: 0,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: { color: '#94a3b8', stepSize: 1 },
        grid: { color: 'rgba(255,255,255,0.05)' }
      },
      x: {
        ticks: { color: '#e2e8f0' },
        grid: { display: false }
      }
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: 'rgba(15, 23, 42, 0.9)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: 'rgba(255,255,255,0.1)',
        borderWidth: 1,
      }
    },
  };

  return (
    <div className="glass-panel" style={{ animationDelay: delay }}>
      <h2 className="poll-title">{poll.question}</h2>
      
      <div className="options-container">
        {poll.options.map(option => {
          // Find current vote count for this option, or default to 0
          const res = results.find(r => r.option_text === option.text);
          const count = res ? res.vote_count : 0;
          return (
            <button 
              key={option.id} 
              className="btn-option"
              onClick={() => onVote(poll.id, option.id)}
            >
              <span>{option.text}</span>
              <span style={{ color: 'var(--text-muted)' }}>{count} votes</span>
            </button>
          );
        })}
      </div>

      <div className="chart-container">
        <Bar data={chartData} options={chartOptions} />
      </div>
    </div>
  );
};

export default PollItem;
