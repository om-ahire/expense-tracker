package com.redberyl.polling.repositories;

import com.redberyl.polling.models.Option;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Map;

@Repository
public interface OptionRepository extends JpaRepository<Option, Long> {
    
    // The query specified in the prompt
    @Query("SELECT o.text AS option_text, COUNT(v.id) AS vote_count " +
           "FROM Option o LEFT JOIN Vote v ON v.option.id = o.id " +
           "WHERE o.poll.id = :pollId " +
           "GROUP BY o.id, o.text")
    List<Map<String, Object>> getPollResults(@Param("pollId") Long pollId);
}
