package com.redberyl.polling.repositories;

import com.redberyl.polling.models.Vote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Long> {
    boolean existsByPollIdAndUserIp(Long pollId, String userIp);
}
