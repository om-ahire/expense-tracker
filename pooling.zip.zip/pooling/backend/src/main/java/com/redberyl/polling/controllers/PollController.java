package com.redberyl.polling.controllers;

import com.redberyl.polling.dto.PollRequest;
import com.redberyl.polling.dto.VoteRequest;
import com.redberyl.polling.models.Option;
import com.redberyl.polling.models.Poll;
import com.redberyl.polling.models.Vote;
import com.redberyl.polling.repositories.OptionRepository;
import com.redberyl.polling.repositories.PollRepository;
import com.redberyl.polling.repositories.VoteRepository;
import com.redberyl.polling.service.VotePublisher;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
public class PollController {

    @Autowired
    private PollRepository pollRepository;

    @Autowired
    private OptionRepository optionRepository;

    @Autowired
    private VoteRepository voteRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private VotePublisher votePublisher;

    @PostMapping("/poll")
    public ResponseEntity<?> createPoll(@RequestBody PollRequest request) {
        Poll poll = new Poll();
        poll.setQuestion(request.getQuestion());
        
        for (String optText : request.getOptions()) {
            Option option = new Option();
            option.setText(optText);
            option.setPoll(poll);
            poll.getOptions().add(option);
        }
        
        Poll saved = pollRepository.save(poll);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/poll")
    public ResponseEntity<List<Poll>> getAllPolls() {
        return ResponseEntity.ok(pollRepository.findAll());
    }

    // This endpoint pushes to the redis queue without saving to DB directly
    @PostMapping("/enqueue-vote")
    public ResponseEntity<?> enqueueVote(@RequestBody VoteRequest voteRequest, HttpServletRequest request) {
        String userIp = request.getRemoteAddr();
        // optionally could check duplicate vote here before enqueuing to save time
        if (voteRepository.existsByPollIdAndUserIp(voteRequest.getPollId(), userIp)) {
            return ResponseEntity.badRequest().body("Already voted on this poll");
        }
        
        voteRequest.setUserIp(userIp);
        votePublisher.enqueueVote(voteRequest);
        return ResponseEntity.accepted().body("Vote queued for processing");
    }

    // The worker calls this endpoint after consuming from Redis
    @PostMapping("/vote/{pollId}/{optionId}")
    public ResponseEntity<?> processVote(@PathVariable Long pollId, 
                                         @PathVariable Long optionId,
                                         @RequestBody(required = false) Map<String, String> body) {
        
        String userIp = "worker-default";
        if (body != null && body.containsKey("user_ip")) {
            userIp = body.get("user_ip");
        }

        // Prevent duplicate vote
        if (voteRepository.existsByPollIdAndUserIp(pollId, userIp)) {
            return ResponseEntity.badRequest().body("Already voted");
        }

        Optional<Poll> pollOpt = pollRepository.findById(pollId);
        Optional<Option> optionOpt = optionRepository.findById(optionId);

        if (pollOpt.isPresent() && optionOpt.isPresent()) {
            Vote vote = new Vote();
            vote.setPoll(pollOpt.get());
            vote.setOption(optionOpt.get());
            vote.setUserIp(userIp);
            voteRepository.save(vote);

            // Broadcast updated results to specific poll topic
            broadcastPollResults(pollId);
            
            return ResponseEntity.ok("Vote recorded successfully");
        }
        return ResponseEntity.badRequest().body("Invalid poll or option ID");
    }

    private void broadcastPollResults(Long pollId) {
        List<Map<String, Object>> results = optionRepository.getPollResults(pollId);
        // We broadcast to /topic/poll/{pollId}
        messagingTemplate.convertAndSend("/topic/poll/" + pollId, results);
    }
}
