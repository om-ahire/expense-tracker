package com.redberyl.polling.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.redberyl.polling.dto.VoteRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class VotePublisher {
    
    @Autowired
    private RedisTemplate<String, String> redisTemplate;
    
    private final ObjectMapper mapper = new ObjectMapper();

    public void enqueueVote(VoteRequest request) {
        try {
            String message = mapper.writeValueAsString(request);
            // Push to right side of the list "vote_events"
            redisTemplate.opsForList().rightPush("vote_events", message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
